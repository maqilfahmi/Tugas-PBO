import 'package:ppb_dart_application_1/ppb_dart_application_1.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
